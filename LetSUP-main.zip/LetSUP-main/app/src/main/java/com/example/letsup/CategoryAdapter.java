package com.example.letsup;

import android.view.View;
import android.view.ViewGroup;

public interface CategoryAdapter {
    View getView(View convertView, int position, ViewGroup parent);

}
